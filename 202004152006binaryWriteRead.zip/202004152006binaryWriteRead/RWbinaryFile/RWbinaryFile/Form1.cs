﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
/*2020-4-15 20:47:46参考c#从入门到精通*/
namespace RWbinaryFile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void write_button1_Click(object sender, EventArgs e)
        {
            string filename = "D:\\binary.IChina";
            if (File.Exists(filename))
            {
                MessageBox.Show("this file exists");
            }
            else
            {
                FileStream fs = new FileStream(filename,FileMode.Create);
                BinaryWriter writer = new BinaryWriter(fs);
                writer.Write(textBox1.Text);
                MessageBox.Show("write success");
                textBox1.Text = "";
                writer.Close();
                fs.Close();
            }
        }

        private void read_button2_Click(object sender, EventArgs e)
        {
            string filename = "D:\\binary.IChina";
            if (!(File.Exists(filename)))
            {
                MessageBox.Show("current file not exists");
                return;
            }
            string strData = "";
            FileStream fs = new FileStream(filename,FileMode.Open,FileAccess.Read);
            BinaryReader reader = new BinaryReader(fs);
            try
            {
                strData = reader.ReadString();
                while (true)
                {
                    strData += "||" + reader.ReadInt32().ToString();
                }
            }
            catch(EndOfStreamException es)
            { 
            
            }
            textBox2.Text = strData;
            fs.Close();
            reader.Close();
        }
    }
}
